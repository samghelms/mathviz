# mathviz
A python package for examining mathematics equation embeddings

# Instructions

install dependencies with pip and then run the jupyter notebook for an example of how to use the table tool.