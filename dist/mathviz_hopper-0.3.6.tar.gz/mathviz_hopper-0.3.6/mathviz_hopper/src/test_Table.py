from Table import Table 

if __name__ == '__main__':
	t = Table()
